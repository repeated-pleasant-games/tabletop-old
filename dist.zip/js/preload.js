/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utility/theme/index.ts":
/*!************************************!*\
  !*** ./src/utility/theme/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.setColors = exports.getColorMode = exports.getThemePreference = void 0;
exports.getThemePreference = () => {
    const storedThemePreference = window.localStorage.getItem('themePreference');
    if (storedThemePreference !== null)
        return storedThemePreference;
    else
        return "system";
};
exports.getColorMode = (themePreference) => {
    switch (themePreference) {
        case "light":
        case "dark":
            return themePreference;
        case "system":
        default:
            {
                const query = window.matchMedia("(prefers-color-scheme: dark)");
                return query.matches ? "dark" : "light";
            }
    }
};
exports.setColors = (colorMode) => window.document.documentElement.className = colorMode;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;
/*!************************!*\
  !*** ./src/preload.ts ***!
  \************************/

Object.defineProperty(exports, "__esModule", ({ value: true }));
const theme_1 = __webpack_require__(/*! ./utility/theme */ "./src/utility/theme/index.ts");
const detectAndSetTheme = () => {
    const themePreference = theme_1.getThemePreference();
    theme_1.setColors(theme_1.getColorMode(themePreference));
    window.document.documentElement.style
        .setProperty(`--theme-preference`, themePreference);
};
detectAndSetTheme();
window.matchMedia("(prefers-color-scheme: dark)")
    .addEventListener("change", detectAndSetTheme);

})();

/******/ })()
;
//# sourceMappingURL=preload.js.map